header TestProgram4
 
  uses UserSystem

  functions
    main ()

endHeader
