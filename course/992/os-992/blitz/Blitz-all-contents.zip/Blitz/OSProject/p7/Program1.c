code Program1

-----------------------------  main  ---------------------------------

  function main ()

      print ("Hello, World!!!\n")
      print ("\n**********  Test Complete  **********\n\n")
      Sys_Exit (0)

    endFunction

endCode
