header Program1
 
  uses UserSystem

  functions
    main ()

endHeader
