header Main

  uses Kernel
 
  functions
    main ()

endHeader
