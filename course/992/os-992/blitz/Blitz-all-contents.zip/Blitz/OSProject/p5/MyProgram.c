code MyProgram

-----------------------------  main  ---------------------------------

  function main ()
    --
    -- This is a generic User-Level program.  Feel free to modify it and
    -- use it during debugging.
    --

      print ("\nMy user-level program is running!!!\n")
      Sys_Shutdown ()

    endFunction

endCode
