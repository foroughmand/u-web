header TestProgram2
 
  uses UserSystem

  functions
    main ()

endHeader
