header TestProgram3
 
  uses UserSystem

  functions
    main ()

endHeader
