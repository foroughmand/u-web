#include <stdio.h>
#include <strings.h>

int i;
char * p;

main () {
  printf ("This program tests whether this computer uses Big Endian or Little Endian byte ordering...\n");
  i = 0x12345678;
  printf ("The following line should print 0x12345678...\n");
  printf ("        0x%08x\n", i);
  printf ("This program stores 11, 22, 33, and 44 in sucessive bytes and then accesses it as a 4 byte integer.\n");
  p = (char *) (& i);
  *p = 0x11;
  p++;
  *p = 0x22;
  p++;
  *p = 0x33;
  p++;
  *p = 0x44;
  printf ("Big Endian machines will print 0x11223344 next...\n");
  printf ("Little Endian machines will print 0x44332211 next...\n");
  printf ("        0x%08x\n", i);
  printf ("Good bye\n");
}
